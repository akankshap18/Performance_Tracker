package com.example.performancetracker.Admin;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.performancetracker.MainActivity;
import com.example.performancetracker.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

public class Lead extends AppCompatActivity {
    TextView fullName, email, phone;
    FirebaseAuth fAuth;
    FirebaseFirestore fstore;
    String managerId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.admin_activity_lead);
        phone = findViewById(R.id.phoneNumber);
        fullName = findViewById(R.id.mName);
        email = findViewById(R.id.mEmail);

        fAuth = FirebaseAuth.getInstance();
        fstore = FirebaseFirestore.getInstance();

        managerId = fAuth.getCurrentUser().getUid();

        DocumentReference documentReference = fstore.collection("managers").document(managerId);
        documentReference.addSnapshotListener(this, (documentSnapshot, error) -> {
            phone.setText(documentSnapshot.getString("phone"));
            fullName.setText(documentSnapshot.getString("fName"));
            email.setText(documentSnapshot.getString("email"));
        });
    }
    public void logout(View view) {
        FirebaseAuth.getInstance().signOut();
        startActivity(new Intent(getApplicationContext(), MainActivity.class));
        finish();
    }
}
