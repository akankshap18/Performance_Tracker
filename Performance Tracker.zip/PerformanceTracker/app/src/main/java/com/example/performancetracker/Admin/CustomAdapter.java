package com.example.performancetracker.Admin;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.performancetracker.R;

import java.util.List;

public class CustomAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    Users user;
    List<Model> modelList;
    Context context;

    public CustomAdapter(Users user, List<Model> modelList, Context context) {
        this.user = user;
        this.modelList = modelList;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View itemView = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.model_layout, viewGroup, false);

        ViewHolder viewHolder = new ViewHolder(itemView);
        viewHolder.setOnClickListener(new ViewHolder.ClickListener() {
            @Override
            public void onItemClick(View view, int position) {

            }

            @Override
            public void onItemLongClick(View view, int position) {

            }
        });
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int position) {
        viewHolder.phoneNumber.setText(modelList.get(position).getPhone());
        viewHolder.fName.setText(modelList.get(position).getName());
        viewHolder.eMail.setText(modelList.get(position).getEmail());
    }

//    @Override
//    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int position) {
//        viewHolder.phoneNumber.setText(modelList.get(position).getPhone());
//        viewHolder.fName.setText(modelList.get(position).getName());
//        viewHolder.eMail.setText(modelList.get(position).getEmail());
//    }

    @Override
    public int getItemCount() {
        return modelList.size();
    }
}
