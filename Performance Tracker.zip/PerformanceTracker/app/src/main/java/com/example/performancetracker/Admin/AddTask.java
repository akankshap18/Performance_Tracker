package com.example.performancetracker.Admin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.performancetracker.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class AddTask extends AppCompatActivity {
    private String TAG = "TAG";
    EditText Task;
    Button Add;
    FirebaseAuth fAuth;
    FirebaseFirestore fstore;
    String reportId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.admin_activity_add_task);

        Task = findViewById(R.id.mTask);
        Add = findViewById(R.id.submit);
        fAuth = FirebaseAuth.getInstance();
        fstore = FirebaseFirestore.getInstance();

        Add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addTaskToFirestore();
            }
        });
    }

    public void addTaskToFirestore() {
        Map<String, String> Tasks = new HashMap<>();
        Tasks.put("Taskname", Task.getText().toString());
        fstore.collection("task").add(Tasks)
            .addOnCompleteListener(new OnCompleteListener<DocumentReference>() {
                @Override
                public void onComplete(@NonNull Task<DocumentReference> task) {
                    Task.setText("");
                    Toast.makeText(getApplicationContext(), "Task added", Toast.LENGTH_LONG).show();
                }
        });
    }
}