package com.example.performancetracker.Admin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.performancetracker.MainActivity;
import com.example.performancetracker.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

public class DeleteUser extends AppCompatActivity {
    TextView fullName, email, phone;
    Button delete, update;
    FirebaseAuth fAuth;
    FirebaseFirestore fstore;
    String userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.admin_activity_delete_user);

        phone = findViewById(R.id.mPhone);
        fullName = findViewById(R.id.mName);
        email = findViewById(R.id.mEmail);
        delete = findViewById(R.id.mDelete);
        update = findViewById(R.id.mUpdate);

        fAuth = FirebaseAuth.getInstance();
        fstore = FirebaseFirestore.getInstance();

        userId = fAuth.getCurrentUser().getUid();

        Task<Void> documentReference = fstore.collection("users").document(userId).delete()
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            // this method is called when the task is success
                            // after deleting we are starting our MainActivity.
                            Toast.makeText(DeleteUser.this, "User has been deleted from firestore.", Toast.LENGTH_SHORT).show();
                            Intent i = new Intent(DeleteUser.this, Admin.class);
                            startActivity(i);
                        } else {
                            // if the delete operation is failed
                            // we are displaying a toast message.
                            Toast.makeText(DeleteUser.this, "Fail to delete the user. ", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }
}