package com.example.performancetracker.User;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.performancetracker.R;

public class Task extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_activity_task);
    }
}