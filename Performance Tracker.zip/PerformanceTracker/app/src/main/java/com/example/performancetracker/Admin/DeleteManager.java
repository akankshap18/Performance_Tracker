package com.example.performancetracker.Admin;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.performancetracker.R;

public class DeleteManager extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.admin_activity_delete_manager);
    }
}